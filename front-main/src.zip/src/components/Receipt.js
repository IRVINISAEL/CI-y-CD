import React from 'react';

const Receipt = ({ receipt }) => {
  return (
    <div className="receipt">
      <h2>Comprobante de Pago</h2>
      {/* Componente para mostrar el recibo */}
    </div>
  );
};

export default Receipt;